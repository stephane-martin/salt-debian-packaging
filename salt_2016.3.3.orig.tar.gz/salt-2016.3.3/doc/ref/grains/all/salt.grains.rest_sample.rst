=======================
salt.grains.rest_sample
=======================

.. automodule:: salt.grains.rest_sample
    :members:
