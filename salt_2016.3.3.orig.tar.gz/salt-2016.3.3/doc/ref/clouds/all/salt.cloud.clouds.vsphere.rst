=========================
salt.cloud.clouds.vsphere
=========================

.. automodule:: salt.cloud.clouds.vsphere
    :members: