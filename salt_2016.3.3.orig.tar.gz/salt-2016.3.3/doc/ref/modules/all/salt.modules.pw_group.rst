=====================
salt.modules.pw_group
=====================

.. automodule:: salt.modules.pw_group
    :members: