===========================
salt.modules.smartos_imgadm
===========================

.. automodule:: salt.modules.smartos_imgadm
    :members: