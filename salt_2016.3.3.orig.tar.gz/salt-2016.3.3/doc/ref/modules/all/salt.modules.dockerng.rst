=====================
salt.modules.dockerng
=====================

.. automodule:: salt.modules.dockerng
    :members:
    :exclude-members: cp, freeze, unfreeze
