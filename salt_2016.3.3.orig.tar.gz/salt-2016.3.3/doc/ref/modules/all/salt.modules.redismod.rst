==================
salt.modules.redis
==================

.. automodule:: salt.modules.redismod
    :members: