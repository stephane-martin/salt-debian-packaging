========================
salt.modules.freebsdjail
========================

.. automodule:: salt.modules.freebsdjail
    :members: