====================
salt.modules.dnsutil
====================

.. automodule:: salt.modules.dnsutil
    :members: