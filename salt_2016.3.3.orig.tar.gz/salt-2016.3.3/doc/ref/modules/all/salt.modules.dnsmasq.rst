====================
salt.modules.dnsmasq
====================

.. automodule:: salt.modules.dnsmasq
    :members: