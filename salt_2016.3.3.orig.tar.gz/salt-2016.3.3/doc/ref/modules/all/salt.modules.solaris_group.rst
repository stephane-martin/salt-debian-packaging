==========================
salt.modules.solaris_group
==========================

.. automodule:: salt.modules.solaris_group
    :members: