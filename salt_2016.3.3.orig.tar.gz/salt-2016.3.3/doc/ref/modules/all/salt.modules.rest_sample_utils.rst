salt.modules.rest_sample_utils module
=====================================

.. automodule:: salt.modules.rest_sample_utils
    :members:
