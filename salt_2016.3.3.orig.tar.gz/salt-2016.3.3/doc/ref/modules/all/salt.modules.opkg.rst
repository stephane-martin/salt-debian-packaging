salt.modules.opkg module
========================

.. automodule:: salt.modules.opkg
    :members:
