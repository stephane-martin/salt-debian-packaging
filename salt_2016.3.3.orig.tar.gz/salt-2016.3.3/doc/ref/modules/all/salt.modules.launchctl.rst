======================
salt.modules.launchctl
======================

.. automodule:: salt.modules.launchctl
    :members: