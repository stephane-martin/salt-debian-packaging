==========================
salt.modules.boto_dynamodb
==========================

.. automodule:: salt.modules.boto_dynamodb
    :members: