===========================
salt.modules.solaris_system
===========================

.. automodule:: salt.modules.solaris_system
    :members:
