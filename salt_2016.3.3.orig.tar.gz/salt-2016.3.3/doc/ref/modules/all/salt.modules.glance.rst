===================
salt.modules.glance
===================

.. automodule:: salt.modules.glance
    :members: