===========================
salt.modules.freebsd_sysctl
===========================

.. automodule:: salt.modules.freebsd_sysctl
    :members: