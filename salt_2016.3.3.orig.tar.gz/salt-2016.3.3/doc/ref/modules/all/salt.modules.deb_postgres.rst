=========================
salt.modules.deb_postgres
=========================

.. automodule:: salt.modules.deb_postgres
    :members:
