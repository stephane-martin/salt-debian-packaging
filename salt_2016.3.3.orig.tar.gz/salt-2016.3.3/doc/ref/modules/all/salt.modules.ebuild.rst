===================
salt.modules.ebuild
===================

.. automodule:: salt.modules.ebuild
    :members:
    :exclude-members: available_version