=========================
salt.modules.boto_route53
=========================

.. automodule:: salt.modules.boto_route53
    :members: