#!/usr/bin/env python
def myfunction():
     grains = {}
     grains['match'] = 'maker'
     return grains
